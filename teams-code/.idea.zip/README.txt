Admin account:
email:            admin@admin.com
wachtwoord: admin

De database moet "fifa-17" heten