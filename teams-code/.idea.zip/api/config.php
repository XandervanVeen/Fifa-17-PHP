<?php
$dbHost = 'localhost';
$dbUser = 'kayleboe_fifa';
$dbPass = 'appelflap123';
$dbname = 'kayleboe_fifa17';

$db = new PDO(
    "mysql:host=$dbHost;dbname=$dbname",
    $dbUser,
    $dbPass
);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>